`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/23/2025 11:20:23 PM
// Design Name: 
// Module Name: sim_110
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module sim_110();

    logic clk = 0;
    always #5 clk = !clk;
    
    logic rst = 1;

    logic[64:0] cur_state;
    logic next_state;
    int rule;

    
    rule110 DUT(
        .clk(clk),
        .rst(rst),
        .cur_state(cur_state),
        .next_state(next_state),
        .rule(rule)
    );

    initial begin
        for(rule = 0; rule < 256; rule = rule + 1) begin
            next_state <= 0;
            rst <= 1;
            @(posedge clk)
            @(posedge clk)
            @(posedge clk)
            @(posedge clk)
            @(posedge clk)
            @(posedge clk)
            rst <= 0;
            next_state <= 1;
            for(int i = 0; i < 65; i = i + 1) begin
                @(posedge clk);
            end
            next_state <= 0;
            @(posedge clk);
        end
        
        $finish();
    end
    
endmodule
