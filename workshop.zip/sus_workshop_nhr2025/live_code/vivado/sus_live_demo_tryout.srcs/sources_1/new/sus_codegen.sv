// THIS IS A GENERATED FILE (Generated at 2025-09-24T01:07:42+02:00)
// This file was generated with SUS Compiler 0.3.1 (c03e217393468a2bbaddabb4691db9b59a788351) built at 2025-09-23T19:06:52+02:00
// matrix_vector_mul_twice #()
module matrix_vector_mul_twice(
	input clk,
	input wire rst,
	output /*mux_wire*/ logic may_start,
	input wire start,
	input wire[31:0] vec[4:0],
	output /*mux_wire*/ logic finish,
	output /*mux_wire*/ logic[31:0] mul_result[4:0]
);

/*latency*/ logic _rst_D1; always_ff @(posedge clk) begin _rst_D1 <= rst; end
/*latency*/ logic _rst_D2; always_ff @(posedge clk) begin _rst_D2 <= _rst_D1; end
/*latency*/ logic _rst_D3; always_ff @(posedge clk) begin _rst_D3 <= _rst_D2; end
/*latency*/ logic _rst_D4; always_ff @(posedge clk) begin _rst_D4 <= _rst_D3; end
/*latency*/ logic _rst_D5; always_ff @(posedge clk) begin _rst_D5 <= _rst_D4; end
/*latency*/ logic _rst_D6; always_ff @(posedge clk) begin _rst_D6 <= _rst_D5; end
/*latency*/ logic _rst_D7; always_ff @(posedge clk) begin _rst_D7 <= _rst_D6; end
/*latency*/ logic _rst_D8; always_ff @(posedge clk) begin _rst_D8 <= _rst_D7; end
/*latency*/ logic _rst_D9; always_ff @(posedge clk) begin _rst_D9 <= _rst_D8; end
/*latency*/ logic _rst_D10; always_ff @(posedge clk) begin _rst_D10 <= _rst_D9; end
/*latency*/ logic _rst_D11; always_ff @(posedge clk) begin _rst_D11 <= _rst_D10; end
/*latency*/ logic _rst_D12; always_ff @(posedge clk) begin _rst_D12 <= _rst_D11; end
/*latency*/ logic _rst_D13; always_ff @(posedge clk) begin _rst_D13 <= _rst_D12; end
/*latency*/ logic _rst_D14; always_ff @(posedge clk) begin _rst_D14 <= _rst_D13; end
/*latency*/ logic _rst_D15; always_ff @(posedge clk) begin _rst_D15 <= _rst_D14; end
/*latency*/ logic _rst_D16; always_ff @(posedge clk) begin _rst_D16 <= _rst_D15; end
/*latency*/ logic _rst_D17; always_ff @(posedge clk) begin _rst_D17 <= _rst_D16; end
/*latency*/ logic _rst_D18; always_ff @(posedge clk) begin _rst_D18 <= _rst_D17; end
/*latency*/ logic _rst_D19; always_ff @(posedge clk) begin _rst_D19 <= _rst_D18; end
/*latency*/ logic _rst_D20; always_ff @(posedge clk) begin _rst_D20 <= _rst_D19; end
/*latency*/ logic _rst_D21; always_ff @(posedge clk) begin _rst_D21 <= _rst_D20; end
/*latency*/ logic _rst_D22; always_ff @(posedge clk) begin _rst_D22 <= _rst_D21; end
/*latency*/ logic _rst_D23; always_ff @(posedge clk) begin _rst_D23 <= _rst_D22; end
/*latency*/ logic _rst_D24; always_ff @(posedge clk) begin _rst_D24 <= _rst_D23; end
/*latency*/ logic _rst_D25; always_ff @(posedge clk) begin _rst_D25 <= _rst_D24; end
/*latency*/ logic _rst_D26; always_ff @(posedge clk) begin _rst_D26 <= _rst_D25; end
/*latency*/ logic _rst_D27; always_ff @(posedge clk) begin _rst_D27 <= _rst_D26; end
/*latency*/ logic _rst_D28; always_ff @(posedge clk) begin _rst_D28 <= _rst_D27; end
/*latency*/ logic _rst_D29; always_ff @(posedge clk) begin _rst_D29 <= _rst_D28; end
/*latency*/ logic _rst_D30; always_ff @(posedge clk) begin _rst_D30 <= _rst_D29; end
/*latency*/ logic _rst_D31; always_ff @(posedge clk) begin _rst_D31 <= _rst_D30; end
/*mux_wire*/ logic _mul_1_rst;
/*mux_wire*/ logic _mul_2_rst;
wire _mul_1_is_active;
wire _4;
assign _4 = !_mul_1_is_active;
/*mux_wire*/ logic _mul_1_start;
/*mux_wire*/ logic[31:0] _mul_1_vec[4:0];
wire _mul_1_finish;
/*latency*/ logic __mul_1_finish_D1; always_ff @(posedge clk) begin __mul_1_finish_D1 <= _mul_1_finish; end
/*latency*/ logic __mul_1_finish_D2; always_ff @(posedge clk) begin __mul_1_finish_D2 <= __mul_1_finish_D1; end
/*latency*/ logic __mul_1_finish_D3; always_ff @(posedge clk) begin __mul_1_finish_D3 <= __mul_1_finish_D2; end
/*latency*/ logic __mul_1_finish_D4; always_ff @(posedge clk) begin __mul_1_finish_D4 <= __mul_1_finish_D3; end
/*latency*/ logic __mul_1_finish_D5; always_ff @(posedge clk) begin __mul_1_finish_D5 <= __mul_1_finish_D4; end
/*latency*/ logic __mul_1_finish_D6; always_ff @(posedge clk) begin __mul_1_finish_D6 <= __mul_1_finish_D5; end
/*latency*/ logic __mul_1_finish_D7; always_ff @(posedge clk) begin __mul_1_finish_D7 <= __mul_1_finish_D6; end
/*latency*/ logic __mul_1_finish_D8; always_ff @(posedge clk) begin __mul_1_finish_D8 <= __mul_1_finish_D7; end
/*latency*/ logic __mul_1_finish_D9; always_ff @(posedge clk) begin __mul_1_finish_D9 <= __mul_1_finish_D8; end
/*latency*/ logic __mul_1_finish_D10; always_ff @(posedge clk) begin __mul_1_finish_D10 <= __mul_1_finish_D9; end
/*latency*/ logic __mul_1_finish_D11; always_ff @(posedge clk) begin __mul_1_finish_D11 <= __mul_1_finish_D10; end
/*latency*/ logic __mul_1_finish_D12; always_ff @(posedge clk) begin __mul_1_finish_D12 <= __mul_1_finish_D11; end
/*latency*/ logic __mul_1_finish_D13; always_ff @(posedge clk) begin __mul_1_finish_D13 <= __mul_1_finish_D12; end
/*latency*/ logic __mul_1_finish_D14; always_ff @(posedge clk) begin __mul_1_finish_D14 <= __mul_1_finish_D13; end
/*latency*/ logic __mul_1_finish_D15; always_ff @(posedge clk) begin __mul_1_finish_D15 <= __mul_1_finish_D14; end
/*latency*/ logic __mul_1_finish_D16; always_ff @(posedge clk) begin __mul_1_finish_D16 <= __mul_1_finish_D15; end
/*latency*/ logic __mul_1_finish_D17; always_ff @(posedge clk) begin __mul_1_finish_D17 <= __mul_1_finish_D16; end
/*latency*/ logic __mul_1_finish_D18; always_ff @(posedge clk) begin __mul_1_finish_D18 <= __mul_1_finish_D17; end
/*latency*/ logic __mul_1_finish_D19; always_ff @(posedge clk) begin __mul_1_finish_D19 <= __mul_1_finish_D18; end
/*latency*/ logic __mul_1_finish_D20; always_ff @(posedge clk) begin __mul_1_finish_D20 <= __mul_1_finish_D19; end
/*latency*/ logic __mul_1_finish_D21; always_ff @(posedge clk) begin __mul_1_finish_D21 <= __mul_1_finish_D20; end
/*latency*/ logic __mul_1_finish_D22; always_ff @(posedge clk) begin __mul_1_finish_D22 <= __mul_1_finish_D21; end
/*latency*/ logic __mul_1_finish_D23; always_ff @(posedge clk) begin __mul_1_finish_D23 <= __mul_1_finish_D22; end
/*latency*/ logic __mul_1_finish_D24; always_ff @(posedge clk) begin __mul_1_finish_D24 <= __mul_1_finish_D23; end
/*latency*/ logic __mul_1_finish_D25; always_ff @(posedge clk) begin __mul_1_finish_D25 <= __mul_1_finish_D24; end
/*latency*/ logic __mul_1_finish_D26; always_ff @(posedge clk) begin __mul_1_finish_D26 <= __mul_1_finish_D25; end
/*latency*/ logic __mul_1_finish_D27; always_ff @(posedge clk) begin __mul_1_finish_D27 <= __mul_1_finish_D26; end
/*latency*/ logic __mul_1_finish_D28; always_ff @(posedge clk) begin __mul_1_finish_D28 <= __mul_1_finish_D27; end
/*latency*/ logic __mul_1_finish_D29; always_ff @(posedge clk) begin __mul_1_finish_D29 <= __mul_1_finish_D28; end
/*latency*/ logic __mul_1_finish_D30; always_ff @(posedge clk) begin __mul_1_finish_D30 <= __mul_1_finish_D29; end
/*latency*/ logic __mul_1_finish_D31; always_ff @(posedge clk) begin __mul_1_finish_D31 <= __mul_1_finish_D30; end
wire[31:0] _mul_1_out_vec[4:0];
/*mux_wire*/ logic[31:0] vec2[4:0];
/*mux_wire*/ logic _mul_2_start;
/*mux_wire*/ logic[31:0] _mul_2_vec[4:0];
wire _mul_2_finish;
/*latency*/ logic __mul_2_finish_D32; always_ff @(posedge clk) begin __mul_2_finish_D32 <= _mul_2_finish; end
/*latency*/ logic __mul_2_finish_D33; always_ff @(posedge clk) begin __mul_2_finish_D33 <= __mul_2_finish_D32; end
/*latency*/ logic __mul_2_finish_D34; always_ff @(posedge clk) begin __mul_2_finish_D34 <= __mul_2_finish_D33; end
/*latency*/ logic __mul_2_finish_D35; always_ff @(posedge clk) begin __mul_2_finish_D35 <= __mul_2_finish_D34; end
/*latency*/ logic __mul_2_finish_D36; always_ff @(posedge clk) begin __mul_2_finish_D36 <= __mul_2_finish_D35; end
/*latency*/ logic __mul_2_finish_D37; always_ff @(posedge clk) begin __mul_2_finish_D37 <= __mul_2_finish_D36; end
/*latency*/ logic __mul_2_finish_D38; always_ff @(posedge clk) begin __mul_2_finish_D38 <= __mul_2_finish_D37; end
/*latency*/ logic __mul_2_finish_D39; always_ff @(posedge clk) begin __mul_2_finish_D39 <= __mul_2_finish_D38; end
/*latency*/ logic __mul_2_finish_D40; always_ff @(posedge clk) begin __mul_2_finish_D40 <= __mul_2_finish_D39; end
/*latency*/ logic __mul_2_finish_D41; always_ff @(posedge clk) begin __mul_2_finish_D41 <= __mul_2_finish_D40; end
/*latency*/ logic __mul_2_finish_D42; always_ff @(posedge clk) begin __mul_2_finish_D42 <= __mul_2_finish_D41; end
/*latency*/ logic __mul_2_finish_D43; always_ff @(posedge clk) begin __mul_2_finish_D43 <= __mul_2_finish_D42; end
/*latency*/ logic __mul_2_finish_D44; always_ff @(posedge clk) begin __mul_2_finish_D44 <= __mul_2_finish_D43; end
/*latency*/ logic __mul_2_finish_D45; always_ff @(posedge clk) begin __mul_2_finish_D45 <= __mul_2_finish_D44; end
/*latency*/ logic __mul_2_finish_D46; always_ff @(posedge clk) begin __mul_2_finish_D46 <= __mul_2_finish_D45; end
/*latency*/ logic __mul_2_finish_D47; always_ff @(posedge clk) begin __mul_2_finish_D47 <= __mul_2_finish_D46; end
/*latency*/ logic __mul_2_finish_D48; always_ff @(posedge clk) begin __mul_2_finish_D48 <= __mul_2_finish_D47; end
/*latency*/ logic __mul_2_finish_D49; always_ff @(posedge clk) begin __mul_2_finish_D49 <= __mul_2_finish_D48; end
/*latency*/ logic __mul_2_finish_D50; always_ff @(posedge clk) begin __mul_2_finish_D50 <= __mul_2_finish_D49; end
/*latency*/ logic __mul_2_finish_D51; always_ff @(posedge clk) begin __mul_2_finish_D51 <= __mul_2_finish_D50; end
/*latency*/ logic __mul_2_finish_D52; always_ff @(posedge clk) begin __mul_2_finish_D52 <= __mul_2_finish_D51; end
/*latency*/ logic __mul_2_finish_D53; always_ff @(posedge clk) begin __mul_2_finish_D53 <= __mul_2_finish_D52; end
/*latency*/ logic __mul_2_finish_D54; always_ff @(posedge clk) begin __mul_2_finish_D54 <= __mul_2_finish_D53; end
/*latency*/ logic __mul_2_finish_D55; always_ff @(posedge clk) begin __mul_2_finish_D55 <= __mul_2_finish_D54; end
/*latency*/ logic __mul_2_finish_D56; always_ff @(posedge clk) begin __mul_2_finish_D56 <= __mul_2_finish_D55; end
/*latency*/ logic __mul_2_finish_D57; always_ff @(posedge clk) begin __mul_2_finish_D57 <= __mul_2_finish_D56; end
/*latency*/ logic __mul_2_finish_D58; always_ff @(posedge clk) begin __mul_2_finish_D58 <= __mul_2_finish_D57; end
/*latency*/ logic __mul_2_finish_D59; always_ff @(posedge clk) begin __mul_2_finish_D59 <= __mul_2_finish_D58; end
/*latency*/ logic __mul_2_finish_D60; always_ff @(posedge clk) begin __mul_2_finish_D60 <= __mul_2_finish_D59; end
/*latency*/ logic __mul_2_finish_D61; always_ff @(posedge clk) begin __mul_2_finish_D61 <= __mul_2_finish_D60; end
/*latency*/ logic __mul_2_finish_D62; always_ff @(posedge clk) begin __mul_2_finish_D62 <= __mul_2_finish_D61; end
wire[31:0] _mul_2_out_vec[4:0];
/*mux_wire*/ logic[31:0] vec3[4:0];
matrix_vector_mul mul_1(
	.clk(clk),
	.is_active(_mul_1_is_active),
	.start(_mul_1_start),
	.vec(_mul_1_vec),
	.finish(_mul_1_finish),
	.out_vec(_mul_1_out_vec),
	.rst(_mul_1_rst)
);
matrix_vector_mul mul_2(
	.clk(clk),
	.is_active(),
	.start(_mul_2_start),
	.vec(_mul_2_vec),
	.finish(_mul_2_finish),
	.out_vec(_mul_2_out_vec),
	.rst(_mul_2_rst)
);
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_mul_1_rst = 1'bx;
	_mul_1_rst = rst;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_mul_2_rst = 1'bx;
	_mul_2_rst = _rst_D31;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	may_start = 1'bx;
	may_start = _4;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_mul_1_start = 1'bx;
	_mul_1_start = 1'b0;
	if(start) _mul_1_start = 1'b1;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_mul_1_vec = '{'x, 'x, 'x, 'x, 'x};
	for(int _v0 = 0; _v0 < 5; _v0 = _v0 + 1) begin
if(start) _mul_1_vec[_v0] = vec[_v0];
end
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	vec2 = '{'x, 'x, 'x, 'x, 'x};
	for(int _v0 = 0; _v0 < 5; _v0 = _v0 + 1) begin
if(__mul_1_finish_D31) vec2[_v0] = _mul_1_out_vec[_v0];
end
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_mul_2_start = 1'bx;
	_mul_2_start = 1'b0;
	if(__mul_1_finish_D31) _mul_2_start = 1'b1;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_mul_2_vec = '{'x, 'x, 'x, 'x, 'x};
	for(int _v0 = 0; _v0 < 5; _v0 = _v0 + 1) begin
if(__mul_1_finish_D31) _mul_2_vec[_v0] = vec2[_v0];
end
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	finish = 1'bx;
	finish = 1'b0;
	if(_mul_2_finish) finish = 1'b1;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	mul_result = '{'x, 'x, 'x, 'x, 'x};
	for(int _v0 = 0; _v0 < 5; _v0 = _v0 + 1) begin
if(__mul_2_finish_D62) mul_result[_v0] = vec3[_v0];
end
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	vec3 = '{'x, 'x, 'x, 'x, 'x};
	for(int _v0 = 0; _v0 < 5; _v0 = _v0 + 1) begin
if(__mul_2_finish_D62) vec3[_v0] = _mul_2_out_vec[_v0];
end
end
endmodule

// matrix_vector_mul #()
module matrix_vector_mul(
	input clk,
	output /*state*/ logic is_active,
	input wire start,
	input wire[31:0] vec[4:0],
	output /*mux_wire*/ logic finish,
	output /*mux_wire*/ logic[31:0] out_vec[4:0],
	input wire rst
);

/*latency*/ logic _is_active_D1; always_ff @(posedge clk) begin _is_active_D1 <= is_active; end
/*latency*/ logic _is_active_D2; always_ff @(posedge clk) begin _is_active_D2 <= _is_active_D1; end
/*latency*/ logic _is_active_D3; always_ff @(posedge clk) begin _is_active_D3 <= _is_active_D2; end
/*latency*/ logic _is_active_D4; always_ff @(posedge clk) begin _is_active_D4 <= _is_active_D3; end
/*latency*/ logic _is_active_D5; always_ff @(posedge clk) begin _is_active_D5 <= _is_active_D4; end
/*latency*/ logic _is_active_D6; always_ff @(posedge clk) begin _is_active_D6 <= _is_active_D5; end
/*latency*/ logic _is_active_D7; always_ff @(posedge clk) begin _is_active_D7 <= _is_active_D6; end
/*latency*/ logic _is_active_D8; always_ff @(posedge clk) begin _is_active_D8 <= _is_active_D7; end
/*latency*/ logic _is_active_D9; always_ff @(posedge clk) begin _is_active_D9 <= _is_active_D8; end
/*latency*/ logic _is_active_D10; always_ff @(posedge clk) begin _is_active_D10 <= _is_active_D9; end
/*latency*/ logic _is_active_D11; always_ff @(posedge clk) begin _is_active_D11 <= _is_active_D10; end
/*latency*/ logic _is_active_D12; always_ff @(posedge clk) begin _is_active_D12 <= _is_active_D11; end
/*latency*/ logic _is_active_D13; always_ff @(posedge clk) begin _is_active_D13 <= _is_active_D12; end
/*latency*/ logic _is_active_D14; always_ff @(posedge clk) begin _is_active_D14 <= _is_active_D13; end
/*latency*/ logic _is_active_D15; always_ff @(posedge clk) begin _is_active_D15 <= _is_active_D14; end
/*latency*/ logic _is_active_D16; always_ff @(posedge clk) begin _is_active_D16 <= _is_active_D15; end
/*latency*/ logic _is_active_D17; always_ff @(posedge clk) begin _is_active_D17 <= _is_active_D16; end
/*latency*/ logic _is_active_D18; always_ff @(posedge clk) begin _is_active_D18 <= _is_active_D17; end
/*latency*/ logic _is_active_D19; always_ff @(posedge clk) begin _is_active_D19 <= _is_active_D18; end
/*latency*/ logic _is_active_D20; always_ff @(posedge clk) begin _is_active_D20 <= _is_active_D19; end
/*latency*/ logic _is_active_D21; always_ff @(posedge clk) begin _is_active_D21 <= _is_active_D20; end
/*latency*/ logic _is_active_D22; always_ff @(posedge clk) begin _is_active_D22 <= _is_active_D21; end
/*latency*/ logic _is_active_D23; always_ff @(posedge clk) begin _is_active_D23 <= _is_active_D22; end
/*latency*/ logic _is_active_D24; always_ff @(posedge clk) begin _is_active_D24 <= _is_active_D23; end
/*latency*/ logic _is_active_D25; always_ff @(posedge clk) begin _is_active_D25 <= _is_active_D24; end
/*latency*/ logic _is_active_D26; always_ff @(posedge clk) begin _is_active_D26 <= _is_active_D25; end
/*latency*/ logic _is_active_D27; always_ff @(posedge clk) begin _is_active_D27 <= _is_active_D26; end
/*latency*/ logic _is_active_D28; always_ff @(posedge clk) begin _is_active_D28 <= _is_active_D27; end
/*latency*/ logic _is_active_D29; always_ff @(posedge clk) begin _is_active_D29 <= _is_active_D28; end
/*latency*/ logic _is_active_D30; always_ff @(posedge clk) begin _is_active_D30 <= _is_active_D29; end
/*latency*/ logic _is_active_D31; always_ff @(posedge clk) begin _is_active_D31 <= _is_active_D30; end
/*latency*/ logic _rst_D1; always_ff @(posedge clk) begin _rst_D1 <= rst; end
/*latency*/ logic _rst_D2; always_ff @(posedge clk) begin _rst_D2 <= _rst_D1; end
/*latency*/ logic _rst_D3; always_ff @(posedge clk) begin _rst_D3 <= _rst_D2; end
/*latency*/ logic _rst_D4; always_ff @(posedge clk) begin _rst_D4 <= _rst_D3; end
/*latency*/ logic _rst_D5; always_ff @(posedge clk) begin _rst_D5 <= _rst_D4; end
/*latency*/ logic _rst_D6; always_ff @(posedge clk) begin _rst_D6 <= _rst_D5; end
/*latency*/ logic _rst_D7; always_ff @(posedge clk) begin _rst_D7 <= _rst_D6; end
/*latency*/ logic _rst_D8; always_ff @(posedge clk) begin _rst_D8 <= _rst_D7; end
/*latency*/ logic _rst_D9; always_ff @(posedge clk) begin _rst_D9 <= _rst_D8; end
genvar _g0;
/*mux_wire*/ logic[31:0] MATRIX[4:0][4:0];
localparam[31:0] _1[4:0][4:0] = '{'{32'h3dcccccd /* 0.1 */, 32'h3e4ccccd /* 0.2 */, 32'h3e99999a /* 0.3 */, 32'h3ecccccd /* 0.4 */, 32'h3f000000 /* 0.5 */}, '{32'hbdcccccd /* -0.1 */, 32'h3e4ccccd /* 0.2 */, 32'h3e99999a /* 0.3 */, 32'h3ecccccd /* 0.4 */, 32'h3fc00000 /* 1.5 */}, '{32'h3dcccccd /* 0.1 */, 32'h3e4ccccd /* 0.2 */, 32'h3e99999a /* 0.3 */, 32'hbecccccd /* -0.4 */, 32'hc0200000 /* -2.5 */}, '{32'h3dcccccd /* 0.1 */, 32'hbe4ccccd /* -0.2 */, 32'hbe99999a /* -0.3 */, 32'h3ecccccd /* 0.4 */, 32'h3f000000 /* 0.5 */}, '{32'h3dcccccd /* 0.1 */, 32'h3e4ccccd /* 0.2 */, 32'h3e99999a /* 0.3 */, 32'h3ecccccd /* 0.4 */, 32'h40600000 /* 3.5 */}};
/*state*/ logic[2:0] cur_idx;
/*state*/ logic[31:0] stored_vec[4:0];
/*mux_wire*/ logic[31:0] cur_col[4:0];
wire[31:0] _6[4:0];
generate
for(_g0 = 0; _g0 < 5; _g0 = _g0 + 1) begin
assign _6[_g0] = MATRIX[cur_idx][_g0];
end
endgenerate
/*latency*/ logic[31:0] __6_D1[4:0]; always_ff @(posedge clk) begin __6_D1 <= _6; end
/*mux_wire*/ logic[31:0] cur_vec_elem;
wire[31:0] _8 = stored_vec[cur_idx];
/*latency*/ logic[31:0] __8_D1; always_ff @(posedge clk) begin __8_D1 <= _8; end
/*mux_wire*/ logic is_last;
/*latency*/ logic _is_last_D1; always_ff @(posedge clk) begin _is_last_D1 <= is_last; end
/*latency*/ logic _is_last_D2; always_ff @(posedge clk) begin _is_last_D2 <= _is_last_D1; end
/*latency*/ logic _is_last_D3; always_ff @(posedge clk) begin _is_last_D3 <= _is_last_D2; end
/*latency*/ logic _is_last_D4; always_ff @(posedge clk) begin _is_last_D4 <= _is_last_D3; end
/*latency*/ logic _is_last_D5; always_ff @(posedge clk) begin _is_last_D5 <= _is_last_D4; end
/*latency*/ logic _is_last_D6; always_ff @(posedge clk) begin _is_last_D6 <= _is_last_D5; end
/*latency*/ logic _is_last_D7; always_ff @(posedge clk) begin _is_last_D7 <= _is_last_D6; end
/*latency*/ logic _is_last_D8; always_ff @(posedge clk) begin _is_last_D8 <= _is_last_D7; end
/*latency*/ logic _is_last_D9; always_ff @(posedge clk) begin _is_last_D9 <= _is_last_D8; end
/*latency*/ logic _is_last_D10; always_ff @(posedge clk) begin _is_last_D10 <= _is_last_D9; end
/*latency*/ logic _is_last_D11; always_ff @(posedge clk) begin _is_last_D11 <= _is_last_D10; end
/*latency*/ logic _is_last_D12; always_ff @(posedge clk) begin _is_last_D12 <= _is_last_D11; end
/*latency*/ logic _is_last_D13; always_ff @(posedge clk) begin _is_last_D13 <= _is_last_D12; end
/*latency*/ logic _is_last_D14; always_ff @(posedge clk) begin _is_last_D14 <= _is_last_D13; end
/*latency*/ logic _is_last_D15; always_ff @(posedge clk) begin _is_last_D15 <= _is_last_D14; end
/*latency*/ logic _is_last_D16; always_ff @(posedge clk) begin _is_last_D16 <= _is_last_D15; end
/*latency*/ logic _is_last_D17; always_ff @(posedge clk) begin _is_last_D17 <= _is_last_D16; end
/*latency*/ logic _is_last_D18; always_ff @(posedge clk) begin _is_last_D18 <= _is_last_D17; end
/*latency*/ logic _is_last_D19; always_ff @(posedge clk) begin _is_last_D19 <= _is_last_D18; end
/*latency*/ logic _is_last_D20; always_ff @(posedge clk) begin _is_last_D20 <= _is_last_D19; end
/*latency*/ logic _is_last_D21; always_ff @(posedge clk) begin _is_last_D21 <= _is_last_D20; end
/*latency*/ logic _is_last_D22; always_ff @(posedge clk) begin _is_last_D22 <= _is_last_D21; end
/*latency*/ logic _is_last_D23; always_ff @(posedge clk) begin _is_last_D23 <= _is_last_D22; end
/*latency*/ logic _is_last_D24; always_ff @(posedge clk) begin _is_last_D24 <= _is_last_D23; end
/*latency*/ logic _is_last_D25; always_ff @(posedge clk) begin _is_last_D25 <= _is_last_D24; end
/*latency*/ logic _is_last_D26; always_ff @(posedge clk) begin _is_last_D26 <= _is_last_D25; end
/*latency*/ logic _is_last_D27; always_ff @(posedge clk) begin _is_last_D27 <= _is_last_D26; end
/*latency*/ logic _is_last_D28; always_ff @(posedge clk) begin _is_last_D28 <= _is_last_D27; end
/*latency*/ logic _is_last_D29; always_ff @(posedge clk) begin _is_last_D29 <= _is_last_D28; end
/*latency*/ logic _is_last_D30; always_ff @(posedge clk) begin _is_last_D30 <= _is_last_D29; end
/*latency*/ logic _is_last_D31; always_ff @(posedge clk) begin _is_last_D31 <= _is_last_D30; end
wire _11;
assign _11 = cur_idx == 3'd4;
wire[2:0] _15;
assign _15 = cur_idx + 1'd1;
wire[2:0] _17;
assign _17 = _15 % 3'd5;
/*mux_wire*/ logic[31:0] output_vec[4:0];
/*mux_wire*/ logic[31:0] this_multiply;
wire[31:0] _19 = cur_col[0];
/*mux_wire*/ logic _fp_mul_fp_mul;
/*mux_wire*/ logic[31:0] _fp_mul_a;
/*mux_wire*/ logic[31:0] _fp_mul_b;
wire[31:0] _fp_mul_result;
/*mux_wire*/ logic _row_accumulate_accumulate;
/*mux_wire*/ logic[31:0] _row_accumulate_v;
/*mux_wire*/ logic _row_accumulate_get_sum;
wire[31:0] _row_accumulate_sum;
/*mux_wire*/ logic _row_accumulate_rst;
/*mux_wire*/ logic[31:0] this_multiply_2;
wire[31:0] _33 = cur_col[1];
/*mux_wire*/ logic _fp_mul_2_fp_mul;
/*mux_wire*/ logic[31:0] _fp_mul_2_a;
/*mux_wire*/ logic[31:0] _fp_mul_2_b;
wire[31:0] _fp_mul_2_result;
/*mux_wire*/ logic _row_accumulate_2_accumulate;
/*mux_wire*/ logic[31:0] _row_accumulate_2_v;
/*mux_wire*/ logic _row_accumulate_2_get_sum;
wire[31:0] _row_accumulate_2_sum;
/*mux_wire*/ logic _row_accumulate_2_rst;
/*mux_wire*/ logic[31:0] this_multiply_3;
wire[31:0] _47 = cur_col[2];
/*mux_wire*/ logic _fp_mul_3_fp_mul;
/*mux_wire*/ logic[31:0] _fp_mul_3_a;
/*mux_wire*/ logic[31:0] _fp_mul_3_b;
wire[31:0] _fp_mul_3_result;
/*mux_wire*/ logic _row_accumulate_3_accumulate;
/*mux_wire*/ logic[31:0] _row_accumulate_3_v;
/*mux_wire*/ logic _row_accumulate_3_get_sum;
wire[31:0] _row_accumulate_3_sum;
/*mux_wire*/ logic _row_accumulate_3_rst;
/*mux_wire*/ logic[31:0] this_multiply_4;
wire[31:0] _61 = cur_col[3];
/*mux_wire*/ logic _fp_mul_4_fp_mul;
/*mux_wire*/ logic[31:0] _fp_mul_4_a;
/*mux_wire*/ logic[31:0] _fp_mul_4_b;
wire[31:0] _fp_mul_4_result;
/*mux_wire*/ logic _row_accumulate_4_accumulate;
/*mux_wire*/ logic[31:0] _row_accumulate_4_v;
/*mux_wire*/ logic _row_accumulate_4_get_sum;
wire[31:0] _row_accumulate_4_sum;
/*mux_wire*/ logic _row_accumulate_4_rst;
/*mux_wire*/ logic[31:0] this_multiply_5;
wire[31:0] _75 = cur_col[4];
/*mux_wire*/ logic _fp_mul_5_fp_mul;
/*mux_wire*/ logic[31:0] _fp_mul_5_a;
/*mux_wire*/ logic[31:0] _fp_mul_5_b;
wire[31:0] _fp_mul_5_result;
/*mux_wire*/ logic _row_accumulate_5_accumulate;
/*mux_wire*/ logic[31:0] _row_accumulate_5_v;
/*mux_wire*/ logic _row_accumulate_5_get_sum;
wire[31:0] _row_accumulate_5_sum;
/*mux_wire*/ logic _row_accumulate_5_rst;
fp_accumulate row_accumulate(
	.clk(clk),
	.accumulate(_row_accumulate_accumulate),
	.v(_row_accumulate_v),
	.get_sum(_row_accumulate_get_sum),
	.sum(_row_accumulate_sum),
	.rst(_row_accumulate_rst)
);
fp_mul fp_mul(
	.clk(clk),
	.fp_mul(_fp_mul_fp_mul),
	.a(_fp_mul_a),
	.b(_fp_mul_b),
	.result(_fp_mul_result)
);
fp_accumulate row_accumulate_2(
	.clk(clk),
	.accumulate(_row_accumulate_2_accumulate),
	.v(_row_accumulate_2_v),
	.get_sum(_row_accumulate_2_get_sum),
	.sum(_row_accumulate_2_sum),
	.rst(_row_accumulate_2_rst)
);
fp_mul fp_mul_2(
	.clk(clk),
	.fp_mul(_fp_mul_2_fp_mul),
	.a(_fp_mul_2_a),
	.b(_fp_mul_2_b),
	.result(_fp_mul_2_result)
);
fp_accumulate row_accumulate_3(
	.clk(clk),
	.accumulate(_row_accumulate_3_accumulate),
	.v(_row_accumulate_3_v),
	.get_sum(_row_accumulate_3_get_sum),
	.sum(_row_accumulate_3_sum),
	.rst(_row_accumulate_3_rst)
);
fp_mul fp_mul_3(
	.clk(clk),
	.fp_mul(_fp_mul_3_fp_mul),
	.a(_fp_mul_3_a),
	.b(_fp_mul_3_b),
	.result(_fp_mul_3_result)
);
fp_accumulate row_accumulate_4(
	.clk(clk),
	.accumulate(_row_accumulate_4_accumulate),
	.v(_row_accumulate_4_v),
	.get_sum(_row_accumulate_4_get_sum),
	.sum(_row_accumulate_4_sum),
	.rst(_row_accumulate_4_rst)
);
fp_mul fp_mul_4(
	.clk(clk),
	.fp_mul(_fp_mul_4_fp_mul),
	.a(_fp_mul_4_a),
	.b(_fp_mul_4_b),
	.result(_fp_mul_4_result)
);
fp_accumulate row_accumulate_5(
	.clk(clk),
	.accumulate(_row_accumulate_5_accumulate),
	.v(_row_accumulate_5_v),
	.get_sum(_row_accumulate_5_get_sum),
	.sum(_row_accumulate_5_sum),
	.rst(_row_accumulate_5_rst)
);
fp_mul fp_mul_5(
	.clk(clk),
	.fp_mul(_fp_mul_5_fp_mul),
	.a(_fp_mul_5_a),
	.b(_fp_mul_5_b),
	.result(_fp_mul_5_result)
);
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	MATRIX = '{'{'x, 'x, 'x, 'x, 'x}, '{'x, 'x, 'x, 'x, 'x}, '{'x, 'x, 'x, 'x, 'x}, '{'x, 'x, 'x, 'x, 'x}, '{'x, 'x, 'x, 'x, 'x}};
	for(int _v0 = 0; _v0 < 5; _v0 = _v0 + 1) begin
for(int _v1 = 0; _v1 < 5; _v1 = _v1 + 1) begin
MATRIX[_v0][_v1] = _1[_v0][_v1];
end
end
end
always_ff @(posedge clk) begin
	if(start) is_active <= 1'b1;
	if(is_last) is_active <= 1'b0;
	if(rst) is_active <= 1'b0;
end
always_ff @(posedge clk) begin
	if(start) cur_idx <= 1'd0;
	if(is_active) cur_idx <= _17;
end
always_ff @(posedge clk) begin
	for(int _v0 = 0; _v0 < 5; _v0 = _v0 + 1) begin
if(start) stored_vec[_v0] <= vec[_v0];
end
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	finish = 1'bx;
	finish = 1'b0;
	if(is_last) finish = 1'b1;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	out_vec = '{'x, 'x, 'x, 'x, 'x};
	for(int _v0 = 0; _v0 < 5; _v0 = _v0 + 1) begin
if(_is_last_D31) out_vec[_v0] = output_vec[_v0];
end
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	cur_col = '{'x, 'x, 'x, 'x, 'x};
	for(int _v0 = 0; _v0 < 5; _v0 = _v0 + 1) begin
cur_col[_v0] = __6_D1[_v0];
end
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	cur_vec_elem = 'x;
	cur_vec_elem = __8_D1;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	is_last = 1'bx;
	is_last = _11;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	output_vec = '{'x, 'x, 'x, 'x, 'x};
	if(_is_active_D31) if(_is_last_D31) output_vec[0] = _row_accumulate_sum;
	if(_is_active_D31) if(_is_last_D31) output_vec[1] = _row_accumulate_2_sum;
	if(_is_active_D31) if(_is_last_D31) output_vec[2] = _row_accumulate_3_sum;
	if(_is_active_D31) if(_is_last_D31) output_vec[3] = _row_accumulate_4_sum;
	if(_is_active_D31) if(_is_last_D31) output_vec[4] = _row_accumulate_5_sum;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	this_multiply = 'x;
	if(_is_active_D9) this_multiply = _fp_mul_result;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_fp_mul_fp_mul = 1'bx;
	_fp_mul_fp_mul = 1'b0;
	if(_is_active_D1) _fp_mul_fp_mul = 1'b1;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_fp_mul_a = 'x;
	if(_is_active_D1) _fp_mul_a = _19;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_fp_mul_b = 'x;
	if(_is_active_D1) _fp_mul_b = cur_vec_elem;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_row_accumulate_accumulate = 1'bx;
	_row_accumulate_accumulate = 1'b0;
	if(_is_active_D9) _row_accumulate_accumulate = 1'b1;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_row_accumulate_v = 'x;
	if(_is_active_D9) _row_accumulate_v = this_multiply;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_row_accumulate_get_sum = 1'bx;
	_row_accumulate_get_sum = 1'b0;
	if(_is_active_D9) if(_is_last_D9) _row_accumulate_get_sum = 1'b1;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_row_accumulate_rst = 1'bx;
	_row_accumulate_rst = 1'b0;
	if(_rst_D9) _row_accumulate_rst = 1'b1;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	this_multiply_2 = 'x;
	if(_is_active_D9) this_multiply_2 = _fp_mul_2_result;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_fp_mul_2_fp_mul = 1'bx;
	_fp_mul_2_fp_mul = 1'b0;
	if(_is_active_D1) _fp_mul_2_fp_mul = 1'b1;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_fp_mul_2_a = 'x;
	if(_is_active_D1) _fp_mul_2_a = _33;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_fp_mul_2_b = 'x;
	if(_is_active_D1) _fp_mul_2_b = cur_vec_elem;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_row_accumulate_2_accumulate = 1'bx;
	_row_accumulate_2_accumulate = 1'b0;
	if(_is_active_D9) _row_accumulate_2_accumulate = 1'b1;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_row_accumulate_2_v = 'x;
	if(_is_active_D9) _row_accumulate_2_v = this_multiply_2;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_row_accumulate_2_get_sum = 1'bx;
	_row_accumulate_2_get_sum = 1'b0;
	if(_is_active_D9) if(_is_last_D9) _row_accumulate_2_get_sum = 1'b1;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_row_accumulate_2_rst = 1'bx;
	_row_accumulate_2_rst = 1'b0;
	if(_rst_D9) _row_accumulate_2_rst = 1'b1;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	this_multiply_3 = 'x;
	if(_is_active_D9) this_multiply_3 = _fp_mul_3_result;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_fp_mul_3_fp_mul = 1'bx;
	_fp_mul_3_fp_mul = 1'b0;
	if(_is_active_D1) _fp_mul_3_fp_mul = 1'b1;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_fp_mul_3_a = 'x;
	if(_is_active_D1) _fp_mul_3_a = _47;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_fp_mul_3_b = 'x;
	if(_is_active_D1) _fp_mul_3_b = cur_vec_elem;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_row_accumulate_3_accumulate = 1'bx;
	_row_accumulate_3_accumulate = 1'b0;
	if(_is_active_D9) _row_accumulate_3_accumulate = 1'b1;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_row_accumulate_3_v = 'x;
	if(_is_active_D9) _row_accumulate_3_v = this_multiply_3;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_row_accumulate_3_get_sum = 1'bx;
	_row_accumulate_3_get_sum = 1'b0;
	if(_is_active_D9) if(_is_last_D9) _row_accumulate_3_get_sum = 1'b1;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_row_accumulate_3_rst = 1'bx;
	_row_accumulate_3_rst = 1'b0;
	if(_rst_D9) _row_accumulate_3_rst = 1'b1;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	this_multiply_4 = 'x;
	if(_is_active_D9) this_multiply_4 = _fp_mul_4_result;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_fp_mul_4_fp_mul = 1'bx;
	_fp_mul_4_fp_mul = 1'b0;
	if(_is_active_D1) _fp_mul_4_fp_mul = 1'b1;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_fp_mul_4_a = 'x;
	if(_is_active_D1) _fp_mul_4_a = _61;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_fp_mul_4_b = 'x;
	if(_is_active_D1) _fp_mul_4_b = cur_vec_elem;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_row_accumulate_4_accumulate = 1'bx;
	_row_accumulate_4_accumulate = 1'b0;
	if(_is_active_D9) _row_accumulate_4_accumulate = 1'b1;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_row_accumulate_4_v = 'x;
	if(_is_active_D9) _row_accumulate_4_v = this_multiply_4;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_row_accumulate_4_get_sum = 1'bx;
	_row_accumulate_4_get_sum = 1'b0;
	if(_is_active_D9) if(_is_last_D9) _row_accumulate_4_get_sum = 1'b1;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_row_accumulate_4_rst = 1'bx;
	_row_accumulate_4_rst = 1'b0;
	if(_rst_D9) _row_accumulate_4_rst = 1'b1;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	this_multiply_5 = 'x;
	if(_is_active_D9) this_multiply_5 = _fp_mul_5_result;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_fp_mul_5_fp_mul = 1'bx;
	_fp_mul_5_fp_mul = 1'b0;
	if(_is_active_D1) _fp_mul_5_fp_mul = 1'b1;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_fp_mul_5_a = 'x;
	if(_is_active_D1) _fp_mul_5_a = _75;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_fp_mul_5_b = 'x;
	if(_is_active_D1) _fp_mul_5_b = cur_vec_elem;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_row_accumulate_5_accumulate = 1'bx;
	_row_accumulate_5_accumulate = 1'b0;
	if(_is_active_D9) _row_accumulate_5_accumulate = 1'b1;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_row_accumulate_5_v = 'x;
	if(_is_active_D9) _row_accumulate_5_v = this_multiply_5;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_row_accumulate_5_get_sum = 1'bx;
	_row_accumulate_5_get_sum = 1'b0;
	if(_is_active_D9) if(_is_last_D9) _row_accumulate_5_get_sum = 1'b1;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_row_accumulate_5_rst = 1'bx;
	_row_accumulate_5_rst = 1'b0;
	if(_rst_D9) _row_accumulate_5_rst = 1'b1;
end
endmodule

// fp_accumulate #()
module fp_accumulate(
	input clk,
	input wire accumulate,
	input wire[31:0] v,
	input wire get_sum,
	output /*mux_wire*/ logic[31:0] sum,
	input wire rst
);

/*latency*/ logic _get_sum_D1; always_ff @(posedge clk) begin _get_sum_D1 <= get_sum; end
/*latency*/ logic _get_sum_D2; always_ff @(posedge clk) begin _get_sum_D2 <= _get_sum_D1; end
/*latency*/ logic _get_sum_D3; always_ff @(posedge clk) begin _get_sum_D3 <= _get_sum_D2; end
/*latency*/ logic _get_sum_D4; always_ff @(posedge clk) begin _get_sum_D4 <= _get_sum_D3; end
/*latency*/ logic _get_sum_D5; always_ff @(posedge clk) begin _get_sum_D5 <= _get_sum_D4; end
/*latency*/ logic _get_sum_D6; always_ff @(posedge clk) begin _get_sum_D6 <= _get_sum_D5; end
/*latency*/ logic _get_sum_D7; always_ff @(posedge clk) begin _get_sum_D7 <= _get_sum_D6; end
/*latency*/ logic _get_sum_D8; always_ff @(posedge clk) begin _get_sum_D8 <= _get_sum_D7; end
/*latency*/ logic _get_sum_D9; always_ff @(posedge clk) begin _get_sum_D9 <= _get_sum_D8; end
/*latency*/ logic _get_sum_D10; always_ff @(posedge clk) begin _get_sum_D10 <= _get_sum_D9; end
/*latency*/ logic _get_sum_D11; always_ff @(posedge clk) begin _get_sum_D11 <= _get_sum_D10; end
/*latency*/ logic _get_sum_D12; always_ff @(posedge clk) begin _get_sum_D12 <= _get_sum_D11; end
/*latency*/ logic _get_sum_D13; always_ff @(posedge clk) begin _get_sum_D13 <= _get_sum_D12; end
/*latency*/ logic _get_sum_D14; always_ff @(posedge clk) begin _get_sum_D14 <= _get_sum_D13; end
/*latency*/ logic _get_sum_D15; always_ff @(posedge clk) begin _get_sum_D15 <= _get_sum_D14; end
/*latency*/ logic _get_sum_D16; always_ff @(posedge clk) begin _get_sum_D16 <= _get_sum_D15; end
/*latency*/ logic _get_sum_D17; always_ff @(posedge clk) begin _get_sum_D17 <= _get_sum_D16; end
/*latency*/ logic _get_sum_D18; always_ff @(posedge clk) begin _get_sum_D18 <= _get_sum_D17; end
/*latency*/ logic _get_sum_D19; always_ff @(posedge clk) begin _get_sum_D19 <= _get_sum_D18; end
/*latency*/ logic _get_sum_D20; always_ff @(posedge clk) begin _get_sum_D20 <= _get_sum_D19; end
/*latency*/ logic _get_sum_D21; always_ff @(posedge clk) begin _get_sum_D21 <= _get_sum_D20; end
/*latency*/ logic _get_sum_D22; always_ff @(posedge clk) begin _get_sum_D22 <= _get_sum_D21; end
/*mux_wire*/ logic _ip_s_axis_a_tvalid;
/*mux_wire*/ logic[31:0] _ip_s_axis_a_tdata;
/*mux_wire*/ logic _ip_s_axis_a_tlast;
wire[31:0] _ip_m_axis_result_tdata;
/*mux_wire*/ logic _ip_aresetn;
fp_accumulate_ip #() ip(
	.aclk(clk),
	.aresetn(_ip_aresetn),
	.s_axis_a_tvalid(_ip_s_axis_a_tvalid),
	.s_axis_a_tdata(_ip_s_axis_a_tdata),
	.s_axis_a_tlast(_ip_s_axis_a_tlast),
	.m_axis_result_tvalid(),
	.m_axis_result_tdata(_ip_m_axis_result_tdata),
	.m_axis_result_tlast()
);
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_ip_s_axis_a_tvalid = 1'bx;
	if(accumulate) _ip_s_axis_a_tvalid = 1'b1;
	if(!accumulate) _ip_s_axis_a_tvalid = 1'b0;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_ip_s_axis_a_tdata = 'x;
	if(accumulate) _ip_s_axis_a_tdata = v;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	sum = 'x;
	if(_get_sum_D22) sum = _ip_m_axis_result_tdata;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_ip_s_axis_a_tlast = 1'bx;
	if(get_sum) _ip_s_axis_a_tlast = 1'b1;
	if(!get_sum) _ip_s_axis_a_tlast = 1'b0;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_ip_aresetn = 1'bx;
	if(rst) _ip_aresetn = 1'b0;
	if(!rst) _ip_aresetn = 1'b1;
end
endmodule

// fp_mul #()
module fp_mul(
	input clk,
	input wire fp_mul,
	input wire[31:0] a,
	input wire[31:0] b,
	output /*mux_wire*/ logic[31:0] result
);

/*latency*/ logic _fp_mul_D1; always_ff @(posedge clk) begin _fp_mul_D1 <= fp_mul; end
/*latency*/ logic _fp_mul_D2; always_ff @(posedge clk) begin _fp_mul_D2 <= _fp_mul_D1; end
/*latency*/ logic _fp_mul_D3; always_ff @(posedge clk) begin _fp_mul_D3 <= _fp_mul_D2; end
/*latency*/ logic _fp_mul_D4; always_ff @(posedge clk) begin _fp_mul_D4 <= _fp_mul_D3; end
/*latency*/ logic _fp_mul_D5; always_ff @(posedge clk) begin _fp_mul_D5 <= _fp_mul_D4; end
/*latency*/ logic _fp_mul_D6; always_ff @(posedge clk) begin _fp_mul_D6 <= _fp_mul_D5; end
/*latency*/ logic _fp_mul_D7; always_ff @(posedge clk) begin _fp_mul_D7 <= _fp_mul_D6; end
/*latency*/ logic _fp_mul_D8; always_ff @(posedge clk) begin _fp_mul_D8 <= _fp_mul_D7; end
/*mux_wire*/ logic _ip_s_axis_a_tvalid;
/*mux_wire*/ logic _ip_s_axis_b_tvalid;
/*mux_wire*/ logic[31:0] _ip_s_axis_a_tdata;
/*mux_wire*/ logic[31:0] _ip_s_axis_b_tdata;
wire[31:0] _ip_m_axis_result_tdata;
/*mux_wire*/ logic _;
wire _ip_m_axis_result_tvalid;
fp_mul_ip #() ip(
	.aclk(clk),
	.s_axis_a_tvalid(_ip_s_axis_a_tvalid),
	.s_axis_a_tdata(_ip_s_axis_a_tdata),
	.s_axis_b_tvalid(_ip_s_axis_b_tvalid),
	.s_axis_b_tdata(_ip_s_axis_b_tdata),
	.m_axis_result_tvalid(_ip_m_axis_result_tvalid),
	.m_axis_result_tdata(_ip_m_axis_result_tdata)
);
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	result = 'x;
	if(_fp_mul_D8) result = _ip_m_axis_result_tdata;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_ip_s_axis_a_tvalid = 1'bx;
	if(fp_mul) _ip_s_axis_a_tvalid = 1'b1;
	if(!fp_mul) _ip_s_axis_a_tvalid = 1'b0;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_ip_s_axis_b_tvalid = 1'bx;
	if(fp_mul) _ip_s_axis_b_tvalid = 1'b1;
	if(!fp_mul) _ip_s_axis_b_tvalid = 1'b0;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_ip_s_axis_a_tdata = 'x;
	if(fp_mul) _ip_s_axis_a_tdata = a;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_ip_s_axis_b_tdata = 'x;
	if(fp_mul) _ip_s_axis_b_tdata = b;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	_ = 1'bx;
	if(_fp_mul_D8) _ = _ip_m_axis_result_tvalid;
end
endmodule

// fp_accumulate_ip #()
// Provided externally
// module fp_accumulate_ip(
// 	input aclk,
// 	input wire aresetn,
// 	input wire s_axis_a_tvalid,
// 	input wire[31:0] s_axis_a_tdata,
// 	input wire s_axis_a_tlast,
// 	output /*mux_wire*/ logic m_axis_result_tvalid,
// 	output /*mux_wire*/ logic[31:0] m_axis_result_tdata,
// 	output /*mux_wire*/ logic m_axis_result_tlast
// );
// fp_mul_ip #()
// Provided externally
// module fp_mul_ip(
// 	input aclk,
// 	input wire s_axis_a_tvalid,
// 	input wire[31:0] s_axis_a_tdata,
// 	input wire s_axis_b_tvalid,
// 	input wire[31:0] s_axis_b_tdata,
// 	output /*mux_wire*/ logic m_axis_result_tvalid,
// 	output /*mux_wire*/ logic[31:0] m_axis_result_tdata
// );
