// THIS IS A GENERATED FILE (Generated at 2025-09-24T01:07:42+02:00)
// This file was generated with SUS Compiler 0.3.1 (c03e217393468a2bbaddabb4691db9b59a788351) built at 2025-09-23T19:06:52+02:00
// combinatorial_logic #()
module combinatorial_logic(
	input clk,
	input wire[3:0] a,
	input wire[3:0] b,
	input wire[3:0] c,
	input wire[3:0] d,
	output /*mux_wire*/ logic[6:0] x,
	output /*mux_wire*/ logic signed[8:0] y
);

/*latency*/ logic[3:0] _c_D0; always_ff @(posedge clk) begin _c_D0 <= c; end
wire[6:0] _3;
assign _3 = a * b;
/*latency*/ logic[6:0] __3_D1; always_ff @(posedge clk) begin __3_D1 <= _3; end
/*mux_wire*/ logic[6:0] c_times_d;
wire[6:0] _6;
assign _6 = c * d;
/*latency*/ logic[6:0] __6_D0; always_ff @(posedge clk) begin __6_D0 <= _6; end
/*mux_wire*/ logic signed[7:0] minus_c;
wire signed[7:0] _9;
assign _9 = c_times_d - _c_D0;
/*latency*/ logic signed[7:0] __9_D1; always_ff @(posedge clk) begin __9_D1 <= _9; end
wire signed[8:0] _12;
assign _12 = x + minus_c;
/*latency*/ logic signed[8:0] __12_D2; always_ff @(posedge clk) begin __12_D2 <= _12; end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	x = 7'dx;
	x = __3_D1;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	y = 9'sdx;
	y = __12_D2;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	c_times_d = 7'dx;
	c_times_d = __6_D0;
end
always_comb begin
	// Combinatorial wires are not defined when not valid. This is just so that the synthesis tool doesn't generate latches
	minus_c = 8'sdx;
	minus_c = __9_D1;
end
endmodule

