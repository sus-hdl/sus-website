create_clock -name myclk -period 3 [get_ports clk]
