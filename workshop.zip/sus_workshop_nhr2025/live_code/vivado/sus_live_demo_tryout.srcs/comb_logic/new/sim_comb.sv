`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/24/2025 01:08:24 AM
// Design Name: 
// Module Name: sim_comb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module sim_comb;

    logic clk = 0;
    always #5 clk = !clk;

    logic[3:0] a;
    logic[3:0] b;
    logic[3:0] c;
    logic[3:0] d;
    logic[6:0] x;
    logic signed[8:0] y;

    
    combinatorial_logic DUT(
        .clk(clk),
        .a(a),
        .b(b),
        .c(c),
        .d(d),
        .x(x),
        .y(y)
    );

    initial begin
        @(posedge clk)
        @(posedge clk)
        @(posedge clk)
        
        c <= 3;
        d <= 5;
        @(posedge clk)
        c <= 'x;
        d <= 'x;
        
        a <= 2;
        b <= 7;
        
        @(posedge clk)
        a <= 'x;
        b <= 'x;
        
        @(posedge clk)
        @(posedge clk)
        @(posedge clk)
        @(posedge clk)
        @(posedge clk)
        @(posedge clk)
        @(posedge clk)
        $finish();
    end
endmodule
