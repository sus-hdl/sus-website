`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/23/2025 07:50:46 PM
// Design Name: 
// Module Name: sim
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module tb;

    logic clk = 0;
    always #5 clk = !clk;
    
    logic rst = 1;

    wire may_start;
    logic start;
    logic[31:0] data[5];
    wire finish;
    wire[31:0] result[5];


    matrix_vector_mul_twice mat_vec_mul_mul (
        .clk(clk),
        .rst(rst),
        .may_start(may_start),
        .start(start),
        .vec(data),
        .finish(finish),
        .mul_result(result)
    );

    initial begin
        #100
        start <= 0;
        #20
        @(posedge clk)
        rst <= 0;

        @(posedge clk)
        @(posedge clk)
        @(posedge clk)
        @(posedge clk)
        @(posedge clk)
        @(posedge clk)
        @(posedge clk)

        data <= '{32'h3dcccccd /* 0.1 */, 32'h3e4ccccd /* 0.2 */, 32'h3e99999a /* 0.3 */, 32'h3ecccccd /* 0.4 */, 32'h3f000000 /* 0.5 */};
        start <= 1;
        @(posedge clk);

        start <= 0;
    end
endmodule


