#!/bin/bash

sus_compiler rule110.sus --standalone rule110

sus_compiler combinatorial_logic.sus --standalone combinatorial_logic

sus_compiler tree_add.sus --standalone tree_add



