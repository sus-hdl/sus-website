#!/bin/bash

sus_compiler matrix_vector_mul.sus --standalone matrix_vector_mul_twice --standalone-file /mnt/noctua2/sus_live_demo_tryout/sus_live_demo_tryout.srcs/sources_1/new/sus_codegen.sv
